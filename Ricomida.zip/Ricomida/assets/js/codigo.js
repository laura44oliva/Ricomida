$(function () {
    $('[data-toggle="tooltip"]').tooltip()
  });

 
  $("#enviarcorreo").click(function(){
    $('[data-toggle="popover"]').popover()
  });


 


$("span").dblclick(function(){
                   $(this).css({"color": "red"});
        });

$(".card").click(function(){
            $(this).hide('slow');
})
